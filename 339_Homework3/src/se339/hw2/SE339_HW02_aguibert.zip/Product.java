/**
 * 
 */
package se339.hw2;

public interface Product
{
    public String getName();

    public double getCost();
}
